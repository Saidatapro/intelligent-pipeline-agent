# Incident Response
- Check deployment changes
- Validate upstreams
- Backfill safely
