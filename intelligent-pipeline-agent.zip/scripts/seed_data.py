from src.data_pipeline.simulator import ensure_db; ensure_db(); print('Seeded pipelines')
