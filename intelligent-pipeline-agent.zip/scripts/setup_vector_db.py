from src.rag.vector_store import ensure_schema; ensure_schema(); print('Schema ready')
