# Optimization
- Increase parallelism
- Exponential backoff
- Partition pruning
